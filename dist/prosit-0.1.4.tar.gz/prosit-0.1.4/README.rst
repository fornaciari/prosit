prosit - ProSiT!
================

.. image:: https://img.shields.io/pypi/v/prosit.svg
        :target: https://pypi.python.org/pypi/prosit

.. image:: https://img.shields.io/github/license/fornaciari/prosit
        :target: https://lbesson.mit-license.org/
        :alt: License

.. image:: https://github.com/fornaciari/prosit/workflows/Python%20Package/badge.svg
        :target: https://github.com/fornaciari/prosit/actions

.. image:: https://readthedocs.org/projects/boostsa/badge/?version=latest
        :target: https://prosit.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://colab.research.google.com/assets/colab-badge.svg
    :target: https://colab.research.google.com/drive/1eewGMqW_cIRqKdWW1tBCFE3T2qVCI_EV#scrollTo=6czDoYOiGpJx
    :alt: Open In Colab

Intro
-----

prosit - ProSiT! is a tool to extract topics from a corpus of documents.

- Free software: MIT license
- Documentation: https://prosit.readthedocs.io.

Google colab
------------

.. |colab1| image:: https://colab.research.google.com/assets/colab-badge.svg
    :target: https://colab.research.google.com/drive/1eewGMqW_cIRqKdWW1tBCFE3T2qVCI_EV#scrollTo=6czDoYOiGpJx
    :alt: Open In Colab

+----------------------------------------------------------------+--------------------+
| Name                                                           | Link               |
+================================================================+====================+
| You can try boostsa here:                                      | |colab1|           |
+----------------------------------------------------------------+--------------------+


Installation
------------

.. code-block:: bash

    pip install -U prosit

Getting started
---------------

First, import ``prosit``:

.. code-block:: python

    from prosit import PST



Then, create a prosit instance.

.. code-block:: python

    boot = Bootstrap()


Inputs
^^^^^^



Outputs
^^^^^^^

By defalut, boostsa produces two output files:

- ``results.tsv``, that contains the experiments' performance and the (possible) significance levels;
- ``outcomes.json``, that contains targets and predictions for all the experimental conditions.

You can define the outputs when you create the instance, using the following parameters:

- ``save_results``, type: ``bool``, default: ``True``. This determines if you want to save the results.
- ``save_outcomes``, type: ``bool``, default: ``True``. This determines if you want to save the experiments' outcomes..
- ``dir_out``, type: ``str``, default: ``''``, that is your working directory. This indicates the directory where to save the results.

For example, if you want to save only the results in a particular folder, you will create an instance like this:

.. code-block:: python

    boot = Bootstrap(save_outcomes=False, dir_out='my/favourite/directory/')


